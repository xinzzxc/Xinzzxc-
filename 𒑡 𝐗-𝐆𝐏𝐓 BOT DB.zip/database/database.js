// =========================================
//  💾 X-GPT DATABASE MANAGER
// =========================================

const fs = require('fs-extra');
const chalk = require('chalk');
const moment = require('moment');

class DB {
    constructor(path) {
        this.path = path;
        this.data = {
            users: [],
            total: 0,
            created: moment().format(),
            updated: moment().format()
        };
    }

    init() {
        try {
            if (fs.existsSync(this.path)) {
                this.data = fs.readJsonSync(this.path);
                console.log(chalk.green(`✅ Database loaded: ${this.data.users.length} users`));
            } else {
                fs.ensureFileSync(this.path);
                fs.writeJsonSync(this.path, this.data, { spaces: 2 });
                console.log(chalk.green('✅ Database created!'));
            }
        } catch (error) {
            console.log(chalk.red('❌ Database error:'), error);
        }
    }

    save() {
        try {
            this.data.updated = moment().format();
            fs.writeJsonSync(this.path, this.data, { spaces: 2 });
            return true;
        } catch (error) {
            console.log(chalk.red('❌ Save error:'), error);
            return false;
        }
    }

    backup() {
        try {
            const backupPath = `${this.path}.backup.${Date.now()}`;
            fs.copySync(this.path, backupPath);
            console.log(chalk.green(`✅ Backup created: ${backupPath}`));
            return true;
        } catch (error) {
            console.log(chalk.red('❌ Backup error:'), error);
            return false;
        }
    }

    // =========================================
    //  👤 USER METHODS
    // =========================================
    addUser(userId, username) {
        userId = userId.trim();
        
        // Cek apakah sudah ada
        const exists = this.data.users.find(u => u.id === userId);
        if (exists) {
            return `❌ User ${username} (${userId}) sudah terdaftar!`;
        }

        // Tambah user
        this.data.users.push({
            id: userId,
            username: username,
            added: moment().format(),
            status: 'active'
        });
        this.data.total = this.data.users.length;
        this.save();

        return `
✅ User BERHASIL ditambahkan!

📋 DETAIL:
🆔 ID: ${userId}
👤 Username: ${username}
📅 Added: ${moment().format('YYYY-MM-DD HH:mm:ss')}
📌 Total Users: ${this.data.total}

⚠️ User ini sekarang bisa akses jailbreak!
        `;
    }

    removeUser(userId) {
        userId = userId.trim();
        
        const userIndex = this.data.users.findIndex(u => u.id === userId);
        if (userIndex === -1) {
            return `❌ User ${userId} tidak ditemukan!`;
        }

        const removedUser = this.data.users[userIndex];
        this.data.users.splice(userIndex, 1);
        this.data.total = this.data.users.length;
        this.save();

        return `
✅ User BERHASIL dihapus!

📋 DETAIL:
🆔 ID: ${removedUser.id}
👤 Username: ${removedUser.username}
📅 Removed: ${moment().format('YYYY-MM-DD HH:mm:ss')}
📌 Total Users: ${this.data.total}
        `;
    }

    getUser(userId) {
        userId = userId.trim();
        return this.data.users.find(u => u.id === userId) || null;
    }

    getUsers() {
        if (this.data.users.length === 0) {
            return '📋 Database kosong! Tidak ada user terdaftar.';
        }

        let list = `
╔══════════════════════════════════════════╗
║  📋 DAFTAR USER JAILBREAK X-GPT         ║
╚══════════════════════════════════════════╝

📌 Total: ${this.data.total} user
📌 Terakhir update: ${this.data.updated}

`;

        this.data.users.forEach((user, index) => {
            list += `${index+1}. ${user.username || user.id} (${user.id}) - ${user.status || 'active'}\n`;
        });

        list += `
⚠️ Hanya user ini yang bisa akses jailbreak!
        `;

        return list;
    }

    checkUser(userId) {
        userId = userId.trim();
        const user = this.getUser(userId);

        if (user) {
            return `
✅ User ${user.username || user.id} TERDAFTAR!

📌 Status: ✅ AKTIF
📅 Added: ${user.added}
📌 Total user: ${this.data.total}

⚠️ User ini bisa akses X-GPT Jailbreak!
            `;
        } else {
            return `
❌ User ${userId} TIDAK TERDAFTAR!

📌 Status: ❌ TIDAK AKTIF
📌 Total user: ${this.data.total}

⚠️ User ini TIDAK bisa akses X-GPT Jailbreak!
            `;
        }
    }

    // =========================================
    //  📤 EXPORT DATABASE
    // =========================================
    exportDB() {
        if (this.data.users.length === 0) {
            return '❌ Database kosong, tidak bisa export!';
        }

        const json = JSON.stringify(this.data, null, 2);
        const filename = `jailbreak_db_${moment().format('YYYYMMDD_HHmmss')}.json`;
        
        const path = `./database/${filename}`;
        fs.writeFileSync(path, json);

        return `
✅ Database berhasil di export!

📌 File: ${filename}
📌 Total Users: ${this.data.total}
📌 Size: ${(json.length / 1024).toFixed(2)} KB

📥 Download file: ${path}
        `;
    }

    resetDB() {
        this.data.users = [];
        this.data.total = 0;
        this.data.created = moment().format();
        this.data.updated = moment().format();
        this.save();

        return `
✅ Database berhasil di reset!

📌 Total Users: 0
📌 Reset: ${moment().format('YYYY-MM-DD HH:mm:ss')}
        `;
    }

    getStats() {
        return `
📊 STATISTIK DATABASE JAILBREAK X-GPT

╔══════════════════════════════════════════╗
║  📌 Total Users: ${this.data.total}      ║
║  📌 Created: ${this.data.created}        ║
║  📌 Last Update: ${this.data.updated}    ║
╚══════════════════════════════════════════╝

📋 LIST USER:
${this.data.users.length > 0 ? this.data.users.map(u => `- ${u.username || u.id} (${u.id})`).join('\n') : '(Kosong)'}
        `;
    }
}

module.exports = DB;