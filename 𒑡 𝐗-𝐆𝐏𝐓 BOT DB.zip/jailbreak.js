// =========================================
//  🔓 JAILBREAK X-GPT COMMANDS
// =========================================

const fs = require('fs-extra');
const chalk = require('chalk');

class Jailbreak {
    constructor(bot, db, config) {
        this.bot = bot;
        this.db = db;
        this.config = config;
        this.setupCommands();
    }

    setupCommands() {
        // =========================================
        //  🔓 JAILBREAK COMMAND
        // =========================================
        this.bot.command('jailbreak', async (ctx) => {
            const userId = ctx.from.id.toString();
            const userData = this.db.getUser(userId);
            const isOwner = userId === this.config.telegram.ownerId;
            
            if (!userData && !isOwner) {
                return ctx.reply('❌ Akses ditolak! Anda tidak terdaftar.\n\n📌 Hubungi @Xzizxc untuk akses.');
            }
            
            // Kirim file jailbreak
            try {
                const filePath = './database/jailbreak.md';
                if (fs.existsSync(filePath)) {
                    await ctx.replyWithDocument({ source: filePath }, {
                        caption: `
╔══════════════════════════════════════════════════╗
║  🔓 X-GPT JAILBREAK FILE                        ║
╚══════════════════════════════════════════════════╝

✅ Anda memiliki akses!

📌 File: X-GPT Jailbreak (${this.config.telegram.version})
📌 User: ${ctx.from.username || ctx.from.id}
📌 Status: ${isOwner ? '👑 OWNER' : '✅ Authorized'}

⚠️ JANGAN BOCORIN FILE INI, KONTOL!
                        `
                    });
                } else {
                    await ctx.reply('❌ File jailbreak tidak ditemukan!');
                }
            } catch (error) {
                await ctx.reply('❌ Gagal mengirim file: ' + error.message);
            }
        });
    }
}

module.exports = Jailbreak;